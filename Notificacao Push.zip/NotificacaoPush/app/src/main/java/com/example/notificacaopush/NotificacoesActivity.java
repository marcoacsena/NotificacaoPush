package com.example.notificacaopush;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NotificacoesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notificacoes);
    }
}